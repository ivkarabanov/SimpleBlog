{
	"title": "tinymce.util",
	"tests": [
		{"title": "JSON", "url": "JSON.html"},
		{"title": "JSONRequest", "url": "JSONRequest.html"},
		{"title": "LocalStorage", "url": "LocalStorage.html"},
		{"title": "URI", "url": "URI.html"},
		{"title": "XHR", "url": "XHR.html"},
		{"title": "All browser types", "url": "Quirks_all.html", "jsrobot": true},
		{"title": "Quirks (Firefox)", "url": "Quirks_firefox.html", "jsrobot": true},
		{"title": "Quirks (IE 8)", "url": "Quirks_ie8.html", "jsrobot": true},
		{"title": "Quirks (Webkit)", "url": "Quirks_webkit.html", "jsrobot": true},
		{"title": "Quirks (Remove)", "url": "Quirks_remove.html", "jsrobot": true}
	]
}
